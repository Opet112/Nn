package dev.zenith.mixin;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(ClientPlayerInteractionManager.class)
public interface InteractionManagerAccessor {
    @Accessor("blockBreakingCooldown")
    int zenith$getBlockBreakingCooldown();

    @Accessor("blockBreakingCooldown")
    void zenith$setBlockBreakingCooldown(int value);
}
