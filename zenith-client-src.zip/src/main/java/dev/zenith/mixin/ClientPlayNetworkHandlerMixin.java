package dev.zenith.mixin;

import dev.zenith.module.impl.Velocity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Velocity: remember the player's motion before the knockback packet is applied and scale the
 * difference afterwards. This avoids touching packet internals.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), require = 0)
    private void zenith$velBefore(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        var p = MinecraftClient.getInstance().player;
        if (p != null && packet.getEntityId() == p.getId()) Velocity.capture();
    }

    @Inject(method = "onEntityVelocityUpdate", at = @At("RETURN"), require = 0)
    private void zenith$velAfter(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        Velocity.apply();
    }

    @Inject(method = "onExplosion", at = @At("HEAD"), require = 0)
    private void zenith$explosionBefore(ExplosionS2CPacket packet, CallbackInfo ci) {
        Velocity.capture();
    }

    @Inject(method = "onExplosion", at = @At("RETURN"), require = 0)
    private void zenith$explosionAfter(ExplosionS2CPacket packet, CallbackInfo ci) {
        Velocity.apply();
    }
}
