package dev.zenith.util;

import dev.zenith.ZenithClient;
import dev.zenith.module.impl.Freecam;
import dev.zenith.module.impl.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Projects world positions onto the HUD so ESP/tracers/nametags can be drawn in 2D without a render pipeline. */
public final class Projector {
    public final int width, height;
    private final Vec3d cam, forward, right, up;
    private final double tanHalf, aspect;

    private Projector(Vec3d cam, Vec3d f, Vec3d r, Vec3d u, double fovDeg, int w, int h) {
        this.cam = cam;
        this.forward = f;
        this.right = r;
        this.up = u;
        this.width = w;
        this.height = h;
        this.tanHalf = Math.tan(Math.toRadians(fovDeg) / 2.0);
        this.aspect = w / (double) h;
    }

    public static Projector create(float partial) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Entity e = mc.getCameraEntity();
        if (e == null || mc.world == null || mc.getWindow() == null) return null;

        Vec3d pos;
        double yaw, pitch;
        if (Freecam.active()) {
            pos = new Vec3d(Freecam.camX(partial), Freecam.camY(partial), Freecam.camZ(partial));
            yaw = Math.toRadians(Freecam.camYaw());
            pitch = Math.toRadians(Freecam.camPitch());
        } else {
            pos = e.getLerpedPos(partial).add(0, e.getEyeHeight(e.getPose()), 0);
            yaw = Math.toRadians(e.getYaw(partial));
            pitch = Math.toRadians(e.getPitch(partial));
        }
        Vec3d f = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d r = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d u = r.crossProduct(f);

        double fov = mc.options.getFov().getValue();
        HudModule hud = ZenithClient.modules().get(HudModule.class);
        if (e instanceof ClientPlayerEntity p && hud != null && hud.fovCorrection.get()) {
            // same speed-based FOV effect vanilla applies (sprinting, speed potions, flying)
            double walk = Math.max(0.0001, p.getAbilities().getWalkSpeed());
            double m = (p.getAttributeValue(EntityAttributes.MOVEMENT_SPEED) / walk + 1.0) / 2.0;
            if (p.getAbilities().flying) m *= 1.1;
            double scale = mc.options.getFovEffectScale().getValue();
            fov *= 1.0 + (m - 1.0) * scale;
        }
        return new Projector(pos, f, r, u, fov, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());
    }

    /** Screen position {x, y}, or null if the point is behind the camera. */
    public double[] project(Vec3d world) {
        Vec3d d = world.subtract(cam);
        double z = d.dotProduct(forward);
        if (z < 0.05) return null;
        double nx = d.dotProduct(right) / (z * tanHalf * aspect);
        double ny = d.dotProduct(up) / (z * tanHalf);
        return new double[]{(nx * 0.5 + 0.5) * width, (0.5 - ny * 0.5) * height};
    }

    /** Screen bounds {minX, minY, maxX, maxY} of a world box, or null if any corner is behind the camera. */
    public double[] box(Box b) {
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            Vec3d corner = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            double[] s = project(corner);
            if (s == null) return null;
            minX = Math.min(minX, s[0]);
            maxX = Math.max(maxX, s[0]);
            minY = Math.min(minY, s[1]);
            maxY = Math.max(maxY, s[1]);
        }
        return new double[]{minX, minY, maxX, maxY};
    }

    /** Box of an entity at its interpolated position. */
    public static Box lerpedBox(Entity e, float partial) {
        Vec3d offset = e.getLerpedPos(partial).subtract(e.getPos());
        return e.getBoundingBox().offset(offset);
    }
}
