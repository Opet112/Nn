package dev.zenith.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Server-side ("silent") rotation with human-like behaviour:
 * <ul>
 *   <li>the rotation moves towards the target with a maximum step per tick (no instant snaps),</li>
 *   <li>every step is quantised to the mouse-sensitivity GCD, like real mouse input,</li>
 *   <li>afterwards it glides back to the real camera rotation instead of snapping.</li>
 * </ul>
 * The movement packets of the tick are built with this rotation (see ClientPlayerEntityMixin);
 * the camera itself never moves.
 */
public final class RotationManager {
    private RotationManager() {}

    private static boolean active;
    private static float yaw, pitch;
    private static int hold;

    private static boolean swapped;
    private static float realYaw, realPitch;

    public static boolean isActive() { return active; }

    public static void reset() { active = false; swapped = false; hold = 0; }

    /** Smallest rotation step a real mouse can produce at the current sensitivity. */
    public static float gcdStep() {
        double s = MinecraftClient.getInstance().options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        return (float) (s * s * s * 8.0 * 0.15);
    }

    /** One rotation step from (cy,cp) towards (ty,tp), limited to {@code maxStep} degrees and GCD-quantised. */
    public static float[] step(float cy, float cp, float ty, float tp, float maxStep, boolean gcd) {
        float dy = MathHelper.wrapDegrees(ty - cy);
        float dp = tp - cp;
        float dist = (float) Math.hypot(dy, dp);
        if (dist > maxStep && dist > 0f) {
            float f = maxStep / dist;
            dy *= f;
            dp *= f;
        }
        if (gcd) {
            float g = Math.max(gcdStep(), 0.0001f);
            dy = Math.round(dy / g) * g;
            dp = Math.round(dp / g) * g;
        }
        return new float[]{cy + dy, MathHelper.clamp(cp + dp, -90f, 90f)};
    }

    /** Asks for the server-side rotation to move towards the target this tick. */
    public static void request(ClientPlayerEntity p, float ty, float tp, float maxStep, boolean gcd) {
        if (!active) {
            yaw = p.getYaw();
            pitch = p.getPitch();
            active = true;
        }
        float[] n = step(yaw, pitch, ty, tp, maxStep, gcd);
        yaw = n[0];
        pitch = n[1];
        hold = 2;
    }

    /** Called once per tick before modules: glides back to the camera rotation when nobody asks for it. */
    public static void tick(ClientPlayerEntity p) {
        if (!active) return;
        if (hold-- > 0) return;
        float dy = MathHelper.wrapDegrees(p.getYaw() - yaw);
        float dp = p.getPitch() - pitch;
        if (Math.hypot(dy, dp) < 1.0) { active = false; return; }
        float[] n = step(yaw, pitch, p.getYaw(), p.getPitch(), 40f, true);
        yaw = n[0];
        pitch = n[1];
    }

    /**
     * Moves the server-side rotation towards {@code point} and reports whether the rotation the server
     * already has (the one sent this tick) points at {@code box}. Attack only when this returns true.
     */
    public static boolean aim(ClientPlayerEntity p, Box box, Vec3d point, double reach, float maxStep, boolean gcd) {
        float[] cur = current(p);
        boolean on = lookingAt(p, cur[0], cur[1], box, reach);
        float[] want = EntityUtil.rotationsTo(p, point);
        request(p, want[0], want[1], maxStep, gcd);
        return on;
    }

    /** The rotation the server currently believes (or the camera's if nothing is requested). */
    public static float[] current(ClientPlayerEntity p) {
        return active ? new float[]{yaw, pitch} : new float[]{p.getYaw(), p.getPitch()};
    }

    /** Would a ray along the given rotation hit {@code box} within {@code reach}? */
    public static boolean lookingAt(ClientPlayerEntity p, float yawDeg, float pitchDeg, Box box, double reach) {
        double yr = Math.toRadians(yawDeg), pr = Math.toRadians(pitchDeg);
        Vec3d dir = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3d eye = p.getEyePos();
        return box.expand(0.05).raycast(eye, eye.add(dir.multiply(reach))).isPresent();
    }

    // ---- hooks called from ClientPlayerEntityMixin around sendMovementPackets ----

    public static void beforeSend(ClientPlayerEntity p) {
        if (!active) return;
        realYaw = p.getYaw();
        realPitch = p.getPitch();
        p.setYaw(yaw);
        p.setPitch(pitch);
        swapped = true;
    }

    public static void afterSend(ClientPlayerEntity p) {
        if (!swapped) return;
        p.setYaw(realYaw);
        p.setPitch(realPitch);
        swapped = false;
    }
}
