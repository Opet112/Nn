package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.entity.player.PlayerEntity;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class PlayerAlert extends Module {
    private final Set<UUID> known = new HashSet<>();
    private boolean primed;

    public PlayerAlert() {
        super("PlayerAlert", "Tells you in chat when a player comes into range.", Category.MISC);
    }

    @Override
    protected void onEnable() { known.clear(); primed = false; }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        Set<UUID> now = new HashSet<>();
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == mc.player) continue;
            now.add(other.getUuid());
            if (primed && known.add(other.getUuid())) {
                String tag = EntityUtil.isFriend(other) ? "§b" : "§c";
                ZenithClient.info(tag + other.getName().getString() + "§f entered range (" + (int) mc.player.distanceTo(other) + "m)");
            }
        }
        known.retainAll(now);
        known.addAll(now);
        primed = true;
    }
}
