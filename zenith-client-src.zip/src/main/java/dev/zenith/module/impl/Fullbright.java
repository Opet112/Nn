package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class Fullbright extends Module {
    public Fullbright() {
        super("Fullbright", "See in the dark (client-side night vision).", Category.RENDER);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        StatusEffectInstance current = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current == null || current.getDuration() < 400) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
        }
    }

    @Override
    protected void onDisable() {
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}
