package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class AutoJump extends Module {
    public AutoJump() {
        super("AutoJump", "Jumps constantly while you move.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null || p.isSneaking()) return;
        if (p.isOnGround() && EntityUtil.isMoving()) p.jump();
    }
}
