package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

public class GlowEsp extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 64, 8, 128, 4));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool hostiles = add(new Setting.Bool("Hostiles", true));
    private final Setting.Bool animals = add(new Setting.Bool("Animals", false));

    public GlowEsp() {
        super("ESP", "Outlines entities through walls using the glow effect.", Category.RENDER);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player) continue;
            boolean want = mc.player.distanceTo(e) <= range.get() && matches(e);
            if (want != e.isGlowing()) e.setGlowing(want);
        }
    }

    private boolean matches(Entity e) {
        if (e instanceof PlayerEntity) return players.get();
        if (e instanceof HostileEntity) return hostiles.get();
        if (e instanceof AnimalEntity) return animals.get();
        return false;
    }

    @Override
    protected void onDisable() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) if (e != mc.player && e.isGlowing()) e.setGlowing(false);
    }
}
