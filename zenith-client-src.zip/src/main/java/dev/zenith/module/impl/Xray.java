package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Only the whitelisted blocks keep their faces. The check runs on the chunk-builder threads, so the
 * whitelist is an immutable snapshot published through a volatile field.
 */
public class Xray extends Module {
    private static volatile boolean active;
    private static volatile Set<Block> whitelist = Set.of();
    private static final Set<String> CUSTOM = new TreeSet<>();
    private static volatile boolean dirty = true;

    private static final String[] ORES = {
            "coal_ore", "deepslate_coal_ore", "iron_ore", "deepslate_iron_ore", "copper_ore", "deepslate_copper_ore",
            "gold_ore", "deepslate_gold_ore", "lapis_ore", "deepslate_lapis_ore", "redstone_ore", "deepslate_redstone_ore",
            "diamond_ore", "deepslate_diamond_ore", "emerald_ore", "deepslate_emerald_ore",
            "nether_gold_ore", "nether_quartz_ore", "ancient_debris"};
    private static final String[] VALUABLE = {
            "diamond_ore", "deepslate_diamond_ore", "emerald_ore", "deepslate_emerald_ore",
            "gold_ore", "deepslate_gold_ore", "nether_gold_ore", "ancient_debris"};
    private static final String[] STORAGE = {
            "chest", "trapped_chest", "ender_chest", "barrel", "furnace", "blast_furnace", "smoker", "hopper",
            "dispenser", "dropper", "spawner", "beacon", "enchanting_table", "end_portal_frame", "end_portal",
            "nether_portal", "anvil", "brewing_stand", "crafting_table"};

    public final Setting.Mode preset = add(new Setting.Mode("Preset", "Ores", "Ores", "Valuable", "Storage", "Netherite", "Custom"));
    public final Setting.Bool showLava = add(new Setting.Bool("Show lava", true));

    private int appliedPreset = -1;
    private boolean appliedLava;

    public Xray() {
        super("Xray", "Hides every block except the ones on your list.", Category.RENDER);
    }

    // ---- hooks used by the mixins (may run on worker threads) ----
    public static boolean active() { return active; }
    public static boolean shouldDraw(BlockState state) { return whitelist.contains(state.getBlock()); }
    public static boolean isWhitelisted(Block block) { return whitelist.contains(block); }

    // ---- custom list (.xray add/remove) ----
    public static List<String> custom() { return new ArrayList<>(CUSTOM); }

    public static void setCustom(List<String> ids) {
        CUSTOM.clear();
        CUSTOM.addAll(ids);
        dirty = true;
    }

    /** @return false if the id is not a known block. */
    public static boolean addCustom(String id) {
        Block b = lookup(id);
        if (b == null) return false;
        CUSTOM.add(Registries.BLOCK.getId(b).toString());
        dirty = true;
        return true;
    }

    public static boolean removeCustom(String id) {
        Block b = lookup(id);
        boolean removed = b != null && CUSTOM.remove(Registries.BLOCK.getId(b).toString());
        if (removed) dirty = true;
        return removed;
    }

    private static Block lookup(String id) {
        Identifier ident = Identifier.tryParse(id.contains(":") ? id : "minecraft:" + id);
        if (ident == null || !Registries.BLOCK.containsId(ident)) return null;
        Block b = Registries.BLOCK.get(ident);
        return b == Blocks.AIR ? null : b;
    }

    private void add(Set<Block> set, String... paths) {
        for (String path : paths) {
            Block b = lookup(path);
            if (b != null) set.add(b);
        }
    }

    private void rebuild() {
        Set<Block> set = new HashSet<>();
        switch (preset.get()) {
            case "Ores" -> add(set, ORES);
            case "Valuable" -> add(set, VALUABLE);
            case "Netherite" -> add(set, "ancient_debris");
            case "Storage" -> {
                add(set, STORAGE);
                for (Block b : Registries.BLOCK) {
                    if (Registries.BLOCK.getId(b).getPath().endsWith("shulker_box")) set.add(b);
                }
            }
            default -> add(set, CUSTOM.toArray(new String[0]));
        }
        if (showLava.get()) set.add(Blocks.LAVA);
        whitelist = Set.copyOf(set);
        appliedPreset = preset.index();
        appliedLava = showLava.get();
        dirty = false;
    }

    private void applyAndReload() {
        rebuild();
        active = true;
        if (mc.worldRenderer != null && mc.world != null) mc.worldRenderer.reload();
    }

    @Override
    protected void onEnable() {
        if (mc.world != null) applyAndReload();
    }

    @Override
    protected void onDisable() {
        active = false;
        if (mc.worldRenderer != null && mc.world != null) mc.worldRenderer.reload();
    }

    @Override
    public void onShutdown() { active = false; }

    @Override
    public void onTick() {
        // also covers "enabled from the saved config": onEnable never ran for that
        if (!active || dirty || appliedPreset != preset.index() || appliedLava != showLava.get()) applyAndReload();
    }

    @Override
    public void onAlwaysTick() {
        if (mc.world == null) active = false; // world gone: mark stale so the next join rebuilds
    }

    @Override
    public String getSuffix() { return preset.get(); }
}
