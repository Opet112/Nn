package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.item.BlockItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class Scaffold extends Module {
    private final Setting.Bool swing = add(new Setting.Bool("Swing", true));

    public Scaffold() {
        super("Scaffold", "Places blocks under your feet while you walk.", Category.MISC);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 1.0, p.getZ());
        if (!mc.world.getBlockState(below).isReplaceable()) return;

        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).getItem() instanceof BlockItem) { slot = i; break; }
        }
        if (slot < 0) return;
        if (p.getInventory().getSelectedSlot() != slot) p.getInventory().setSelectedSlot(slot);

        for (Direction d : Direction.values()) {
            if (d == Direction.UP) continue;
            BlockPos neighbor = below.offset(d);
            if (mc.world.getBlockState(neighbor).isReplaceable()) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(neighbor).add(Vec3d.of(face.getVector()).multiply(0.5));
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, face, neighbor, false));
            if (swing.get()) p.swingHand(Hand.MAIN_HAND);
            return;
        }
    }
}
