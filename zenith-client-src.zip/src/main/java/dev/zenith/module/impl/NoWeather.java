package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

public class NoWeather extends Module {
    public NoWeather() {
        super("NoWeather", "Hides rain and thunder.", Category.RENDER);
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        mc.world.setRainGradient(0f);
        mc.world.setThunderGradient(0f);
    }
}
