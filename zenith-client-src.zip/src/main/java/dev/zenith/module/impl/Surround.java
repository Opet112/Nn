package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.BlockUtil;
import dev.zenith.util.InventoryUtil;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class Surround extends Module {
    private final Setting.Num perTick = add(new Setting.Num("Blocks per tick", 2, 1, 4, 1));
    private final Setting.Bool disableOnMove = add(new Setting.Bool("Disable when moved", true));
    private final Setting.Bool switchBack = add(new Setting.Bool("Switch back", true));
    private BlockPos origin;

    public Surround() {
        super("Surround", "Boxes your feet in with obsidian.", Category.COMBAT);
    }

    @Override
    protected void onEnable() { origin = mc.player == null ? null : mc.player.getBlockPos(); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (origin == null) origin = p.getBlockPos();
        if (disableOnMove.get() && !p.getBlockPos().equals(origin)) { setEnabled(false); return; }

        int slot = InventoryUtil.findHotbar(Items.OBSIDIAN);
        if (slot < 0) return;

        int previous = p.getInventory().getSelectedSlot();
        int placed = 0;
        for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            if (placed >= perTick.getInt()) break;
            BlockPos pos = origin.offset(d);
            if (!BlockUtil.canPlaceAt(pos)) continue;
            InventoryUtil.select(slot);
            if (BlockUtil.place(pos, Hand.MAIN_HAND, true)) placed++;
        }
        if (placed > 0 && switchBack.get()) InventoryUtil.select(previous);
    }
}
