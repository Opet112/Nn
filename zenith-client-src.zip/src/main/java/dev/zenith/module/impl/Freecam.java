package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.KeyUtil;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Detaches the camera from your player. The camera position/rotation are applied by CameraMixin,
 * mouse look is redirected by EntityMixin, and your own movement keys are released every tick so the
 * player stays where it is. The idea (hook points) follows the way open-source clients such as
 * Meteor Client do it; the code here is original.
 */
public class Freecam extends Module {
    private static Freecam instance;

    private final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.1, 5.0, 0.1));
    private final Setting.Bool disableOnDamage = add(new Setting.Bool("Disable on damage", false));
    private final Setting.Bool reloadChunks = add(new Setting.Bool("Reload chunks", true));

    private double x, y, z, px, py, pz;
    private float yaw, pitch;
    private Perspective savedPerspective;

    public Freecam() {
        super("Freecam", "Fly the camera around while your player stays put.", Category.RENDER);
        instance = this;
    }

    // ---- accessors used by the mixins and the 2D projector ----
    public static boolean active() { return instance != null && instance.isEnabled(); }
    public static double camX(float t) { return MathHelper.lerp((double) t, instance.px, instance.x); }
    public static double camY(float t) { return MathHelper.lerp((double) t, instance.py, instance.y); }
    public static double camZ(float t) { return MathHelper.lerp((double) t, instance.pz, instance.z); }
    public static float camYaw() { return instance.yaw; }
    public static float camPitch() { return instance.pitch; }

    /** Called by EntityMixin instead of rotating the player. */
    public static void look(double dx, double dy) {
        if (instance == null) return;
        instance.yaw += (float) (dx * 0.15);
        instance.pitch = MathHelper.clamp(instance.pitch + (float) (dy * 0.15), -90f, 90f);
    }

    @Override
    public boolean persistEnabled() { return false; }

    @Override
    protected void onEnable() {
        var p = mc.player;
        if (p == null || mc.world == null) { setEnabled(false); return; }
        Vec3d eye = p.getEyePos();
        x = px = eye.x;
        y = py = eye.y;
        z = pz = eye.z;
        yaw = p.getYaw();
        pitch = p.getPitch();
        savedPerspective = mc.options.getPerspective();
        if (reloadChunks.get()) mc.worldRenderer.reload();
    }

    @Override
    protected void onDisable() { restore(); }

    @Override
    public void onShutdown() { restore(); }

    private void restore() {
        if (savedPerspective != null) mc.options.setPerspective(savedPerspective);
        savedPerspective = null;
        if (reloadChunks.get() && mc.world != null) mc.execute(() -> mc.worldRenderer.reload());
    }

    /** Runs before vanilla samples the keyboard: release the movement keys so the player does not walk. */
    @Override
    public void onPreTick() {
        if (mc.currentScreen != null) return;
        var o = mc.options;
        for (KeyBinding k : new KeyBinding[]{o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sneakKey, o.sprintKey}) {
            k.setPressed(false);
        }
    }

    @Override
    public void onAlwaysTick() {
        if (mc.player == null || mc.world == null) setEnabled(false); // left the world
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (disableOnDamage.get() && p.hurtTime > 0) { setEnabled(false); return; }
        if (mc.options.getPerspective() != Perspective.FIRST_PERSON) mc.options.setPerspective(Perspective.FIRST_PERSON);

        px = x;
        py = y;
        pz = z;
        if (mc.currentScreen != null) return;

        var o = mc.options;
        Vec3d forward = Vec3d.fromPolar(0, yaw);
        Vec3d right = Vec3d.fromPolar(0, yaw + 90);
        double step = (KeyUtil.isDown(o.sprintKey) ? 1.0 : 0.5) * speed.get();

        double f = (KeyUtil.isDown(o.forwardKey) ? 1 : 0) - (KeyUtil.isDown(o.backKey) ? 1 : 0);
        double r = (KeyUtil.isDown(o.rightKey) ? 1 : 0) - (KeyUtil.isDown(o.leftKey) ? 1 : 0);
        double v = (KeyUtil.isDown(o.jumpKey) ? 1 : 0) - (KeyUtil.isDown(o.sneakKey) ? 1 : 0);
        if (f != 0 && r != 0) { f *= Math.sqrt(0.5); r *= Math.sqrt(0.5); }

        x += (forward.x * f + right.x * r) * step;
        z += (forward.z * f + right.z * r) * step;
        y += v * step;
    }
}
