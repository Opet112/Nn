package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private final Setting.Num multiplier = add(new Setting.Num("Multiplier", 1.25, 1.0, 3.0, 0.05));
    private final Setting.Bool autoJump = add(new Setting.Bool("Auto jump", false));

    public Speed() {
        super("Speed", "Moves faster while walking.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        boolean moving = mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
        if (!moving) return;
        if (autoJump.get() && p.isOnGround()) p.jump();
        Vec3d v = p.getVelocity();
        double m = multiplier.get();
        // clamp so repeated multiplication cannot run away
        double hx = v.x * m, hz = v.z * m;
        double h = Math.sqrt(hx * hx + hz * hz);
        double cap = 0.6 * m;
        if (h > cap) { hx *= cap / h; hz *= cap / h; }
        p.setVelocity(hx, v.y, hz);
    }
}
