package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

public class NoSlow extends Module {
    private static NoSlow instance;

    public NoSlow() {
        super("NoSlow", "No slowdown while eating, drinking, blocking or drawing a bow.", Category.MOVEMENT);
        instance = this;
    }

    public static boolean active() { return instance != null && instance.isEnabled(); }
}
