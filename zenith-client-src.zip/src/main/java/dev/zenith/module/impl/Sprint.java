package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Always sprint while moving forward.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
