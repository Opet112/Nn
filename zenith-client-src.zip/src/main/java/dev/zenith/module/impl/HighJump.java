package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.math.Vec3d;

public class HighJump extends Module {
    private final Setting.Num power = add(new Setting.Num("Power", 0.9, 0.5, 3.0, 0.1));

    public HighJump() {
        super("HighJump", "Jump much higher.", Category.MISC);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (p.isOnGround() && mc.options.jumpKey.isPressed()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, power.get(), v.z);
        }
    }
}
